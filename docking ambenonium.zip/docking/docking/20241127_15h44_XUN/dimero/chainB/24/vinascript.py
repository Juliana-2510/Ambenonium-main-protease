import os
import time

path_folder = '/home/thor/Sheila/dimero/chainB/24' #modificar aqui a pasta de origem onde estao todos os arquivos
ligantes = [os.path.splitext(arquivo)[0] for arquivo in os.listdir(path_folder) if arquivo.endswith('.mol2')]

print(ligantes)

receptor = [os.path.splitext(arquivo)[0] for arquivo in os.listdir(path_folder) if arquivo.endswith('.pdb')]

print(receptor)


config = "config.txt"

# Nome do arquivo para gravar os tempos
log_tempo = "tempo_execucao.log"

# Inicia o contador de tempo total
start_time_total = time.time()

# Preparando os receptores e convertendo de pdb para pdbqt (Loops)
with open(log_tempo, "w") as log_file:
    for r in receptor:
        os.system(f"/home/thor/MGLTools-1.5.7/mgltools_x86_64Linux2_1.5.7/bin/pythonsh prepare_receptor4.py -r {r}.pdb -o {r}.pdbqt")
        for l in ligantes:
            os.system(f"/home/thor/MGLTools-1.5.7/mgltools_x86_64Linux2_1.5.7/bin/pythonsh prepare_ligand4.py -l {l}.mol2 -o {l}.pdbqt")
            
            print(f"Executando Vina para {l} e {r}...")
            start_time = time.time()  # Inicia o contador de tempo
            os.system(f"/bin/vina --receptor {r}.pdbqt --ligand {l}.pdbqt --out ./output/out_{l}_{r}.pdbqt --config {config} > ./log/result_{l}_{r}.log 2>&1")
            end_time = time.time()  # Finaliza o contador de tempo
            
            tempo_execucao = round(end_time - start_time, 2)
            print(f"Vina concluído para {l} e {r}. Tempo de execução: {tempo_execucao} segundos.")
            log_file.write(f"Vina para {l} e {r}: {tempo_execucao} segundos.\n\n")

    # Finaliza o contador de tempo total
    end_time_total = time.time()
    tempo_total = round(end_time_total - start_time_total, 2)
    print(f"Tempo total de execução do script: {tempo_total} segundos.")
    log_file.write(f"Tempo total de execução do script: {tempo_total} segundos.\n\n")




